var classLT__PMBusDeviceLTC3886 =
[
    [ "detect", "classLT__PMBusDeviceLTC3886.html#a510c3bca8a1dd5847a4cc3d9a2fc22fa", null ],
    [ "getCapabilities", "classLT__PMBusDeviceLTC3886.html#aaef06f1a272e54755b1004be5e0ee3d9", null ],
    [ "getNumPages", "classLT__PMBusDeviceLTC3886.html#a2792dd263fa3075c029f84ff3f867d45", null ],
    [ "hasCapability", "classLT__PMBusDeviceLTC3886.html#a890f8d2db287c4dc0a77de84e9be1e14", null ],
    [ "LT_PMBusDeviceLTC3886", "classLT__PMBusDeviceLTC3886.html#ad530f8bd7d3d32afe32793e8a7914dbe", null ],
    [ "cap_", "classLT__PMBusDeviceLTC3886.html#a19a399364ea6ac88fdca09bdce6b24a8", null ]
];