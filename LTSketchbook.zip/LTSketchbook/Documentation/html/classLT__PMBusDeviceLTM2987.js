var classLT__PMBusDeviceLTM2987 =
[
    [ "clearFaultLog", "classLT__PMBusDeviceLTM2987.html#ad63fb27a8015d924349576dba8eb789b", null ],
    [ "detect", "classLT__PMBusDeviceLTM2987.html#ade54ff8e887aa1808d792fc27089d5c7", null ],
    [ "disableFaultLog", "classLT__PMBusDeviceLTM2987.html#a9e3cf01f4d9911d16d78ceeaed3bf4cc", null ],
    [ "enableFaultLog", "classLT__PMBusDeviceLTM2987.html#a764c7220acabe913fa4a8236ac0d6aa0", null ],
    [ "getCapabilities", "classLT__PMBusDeviceLTM2987.html#a723bda04ac7a6d8b7a9a6b6d38eb4b80", null ],
    [ "getFaultLog", "classLT__PMBusDeviceLTM2987.html#a3810a2ca9db4b2cf681f57eeefb511d9", null ],
    [ "getNumPages", "classLT__PMBusDeviceLTM2987.html#a6cd26fc7eadd96de07ab95f54643354f", null ],
    [ "getType", "classLT__PMBusDeviceLTM2987.html#a7588676dbad98479f799e56f901b6dd0", null ],
    [ "hasCapability", "classLT__PMBusDeviceLTM2987.html#a992085da902eb69f12e0a53281f0c489", null ],
    [ "hasFaultLog", "classLT__PMBusDeviceLTM2987.html#a821db2c459d0b43c8a70fafb449a9d6a", null ],
    [ "LT_PMBusDeviceLTM2987", "classLT__PMBusDeviceLTM2987.html#a78935e999e84db184d01b923585ae225", null ],
    [ "cap_", "classLT__PMBusDeviceLTM2987.html#a4191e12bf9a1f56733ea6a6d28a7324d", null ]
];