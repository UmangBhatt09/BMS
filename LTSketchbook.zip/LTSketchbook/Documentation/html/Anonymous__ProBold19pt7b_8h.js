var Anonymous__ProBold19pt7b_8h =
[
    [ "PROGMEM", "Anonymous__ProBold19pt7b_8h.html#a6aa4f11dd50a123d845d9cdba08d85fd", null ]
];