var classAdafruit__FT6206 =
[
    [ "autoCalibrate", "classAdafruit__FT6206.html#a6f707193f5cdd73a313c8b42c4e60f82", null ],
    [ "begin", "classAdafruit__FT6206.html#a8a72026ec50cd99001bb252d7ce9e3b0", null ],
    [ "getPoint", "classAdafruit__FT6206.html#aed70c2a7ce46e1104e557a31bcdba3e7", null ],
    [ "readData", "classAdafruit__FT6206.html#adc47d176f29146100c1b17e8149f42c5", null ],
    [ "readRegister8", "classAdafruit__FT6206.html#ac3d12bb58586907c0bf1eb22363e8e53", null ],
    [ "touched", "classAdafruit__FT6206.html#a7e3e739ed53173ec240714563b252419", null ],
    [ "writeRegister8", "classAdafruit__FT6206.html#aaa427ef06e22db59596d732fa4cac392", null ],
    [ "Adafruit_FT6206", "classAdafruit__FT6206.html#aa35eb0e3808a481c814492a8c875f10d", null ]
];