var CN_0413_8ino =
[
    [ "loop", "CN-0413_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_temperature", "CN-0413_8ino.html#ac0acd4a457954ff68adabd24bad7cc8c", null ],
    [ "menu_2_asdf", "CN-0413_8ino.html#a0a2ab39cd156cffa471a177db0b4afd5", null ],
    [ "menu_3_asdf", "CN-0413_8ino.html#a6c18333d2ce4d29dc8c83298b07a769c", null ],
    [ "menu_4_asdf", "CN-0413_8ino.html#aafb9b4148c28c99e929e7f3db92756b9", null ],
    [ "print_prompt", "CN-0413_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "CN-0413_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "setup", "CN-0413_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "connected", "CN-0413_8ino.html#aeec69b1591d87e71937700c76eae7d16", null ],
    [ "device", "CN-0413_8ino.html#acc917725b867a8a1741d1f2e4f611568", null ],
    [ "i2c_params", "CN-0413_8ino.html#ae81d0ad625e55277939d074aba231f1b", null ],
    [ "init_params", "CN-0413_8ino.html#aac579ecd8b15ce1b305a3170652a7382", null ]
];