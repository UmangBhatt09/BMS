var classLT__PMBusDeviceLTC3882 =
[
    [ "clearFaultLog", "classLT__PMBusDeviceLTC3882.html#a61f5d8e345c43a465c95739fe1df844e", null ],
    [ "detect", "classLT__PMBusDeviceLTC3882.html#a42c0211cdadc68710a1d9fec32c6e828", null ],
    [ "disableFaultLog", "classLT__PMBusDeviceLTC3882.html#a956b70d416fbd8e448d89f76fe502087", null ],
    [ "enableFaultLog", "classLT__PMBusDeviceLTC3882.html#aeeb85b3475f44683a00a30b7bc3be5e3", null ],
    [ "getCapabilities", "classLT__PMBusDeviceLTC3882.html#af1ff9ebee8acc60c8933a00ea11da504", null ],
    [ "getFaultLog", "classLT__PMBusDeviceLTC3882.html#acb6cb91735f9745dff1f7ef6fbc2f198", null ],
    [ "getNumPages", "classLT__PMBusDeviceLTC3882.html#acd8b82af654a14138d3629ac30bcf306", null ],
    [ "hasCapability", "classLT__PMBusDeviceLTC3882.html#a8fee80d49fa381def1970a2e735f7079", null ],
    [ "hasFaultLog", "classLT__PMBusDeviceLTC3882.html#af623ef7371a2cabacb7dfdbbd2b94502", null ],
    [ "LT_PMBusDeviceLTC3882", "classLT__PMBusDeviceLTC3882.html#a65b058b5732d93feaec54c220047500e", null ],
    [ "cap_", "classLT__PMBusDeviceLTC3882.html#a603eb29071428c83a9cfb0ae86671a7c", null ]
];