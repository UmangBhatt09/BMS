var classLT__PMBusDeviceLTC2975 =
[
    [ "detect", "classLT__PMBusDeviceLTC2975.html#ab8c78f545c85814ddb63cbdf7cf354cd", null ],
    [ "getCapabilities", "classLT__PMBusDeviceLTC2975.html#a8272e38096c9fe0174f888db1d109443", null ],
    [ "getNumPages", "classLT__PMBusDeviceLTC2975.html#ab68ec0d7846a7660545a06634fe7022c", null ],
    [ "getType", "classLT__PMBusDeviceLTC2975.html#afe263dcceaef5ae6cb4eee5f7b674634", null ],
    [ "hasCapability", "classLT__PMBusDeviceLTC2975.html#afa6025083dd4ee79765404e6af087ff8", null ],
    [ "LT_PMBusDeviceLTC2975", "classLT__PMBusDeviceLTC2975.html#ab2de0d662392ce6d59c818c7aeaf4ecc", null ],
    [ "cap_", "classLT__PMBusDeviceLTC2975.html#a81eaa6dbeb8f5aca6c119cd23e00403d", null ]
];