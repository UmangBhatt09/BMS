var classGFXcanvas1 =
[
    [ "drawPixel", "classGFXcanvas1.html#a0859d124c8dcaa147ef22a54d6e843a8", null ],
    [ "fillScreen", "classGFXcanvas1.html#aa282792bbb854a4a045be5ba1c8a7afc", null ],
    [ "getBuffer", "classGFXcanvas1.html#a008d7c6d8db9f641cef9d345959f732b", null ],
    [ "GFXcanvas1", "classGFXcanvas1.html#a3d8047501178f976fb6af095572eb5d0", null ],
    [ "~GFXcanvas1", "classGFXcanvas1.html#a5c6dad65db4c9a99544f3b5bad4c86e8", null ]
];