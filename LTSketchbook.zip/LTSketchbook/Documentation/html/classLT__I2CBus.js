var classLT__I2CBus =
[
    [ "changeSpeed", "classLT__I2CBus.html#a11233e6781f4c0db3073a413f04733ce", null ],
    [ "endGroupProtocol", "classLT__I2CBus.html#a26d423e36b10334f2cc0533286e85294", null ],
    [ "getSpeed", "classLT__I2CBus.html#ab8d4835a130717f0680fb7c481a3ef6f", null ],
    [ "quikevalI2CConnect", "classLT__I2CBus.html#ab7cb4c1fc641ae5ccce02873f0ad1487", null ],
    [ "quikevalI2CInit", "classLT__I2CBus.html#a17b6e686eaf940edaa55d62df46a700b", null ],
    [ "readBlockData", "classLT__I2CBus.html#adb2ce5898fe95238f3b5453845a4a9c4", null ],
    [ "readBlockData", "classLT__I2CBus.html#a000d816a6b81f77f4428d7130d2a7ea2", null ],
    [ "readBlockDataPec", "classLT__I2CBus.html#a0f96261dcfb05265fa1b681552e5b6dd", null ],
    [ "readBlockDataPec", "classLT__I2CBus.html#ad1f9142e54dd5268db1402c4125e7f20", null ],
    [ "readByte", "classLT__I2CBus.html#a5080cf319ce1c031cdf8b253fc995a23", null ],
    [ "readByteData", "classLT__I2CBus.html#ae0e744642e06e7190d2fa4a3e26bb469", null ],
    [ "readWordData", "classLT__I2CBus.html#aa8df3715531d279b5c47425e21c942ba", null ],
    [ "startGroupProtocol", "classLT__I2CBus.html#a8e20f4f7f67e4de75c9dce233b500e42", null ],
    [ "twoByteCommandReadBlock", "classLT__I2CBus.html#a407c5ce28cde515caf72ade1a426b4b9", null ],
    [ "writeBlockData", "classLT__I2CBus.html#ac2c712cf827def1aeebf7f195acaef6a", null ],
    [ "writeByte", "classLT__I2CBus.html#a4a7921b52e2a9c9484f61ea513d8fa6c", null ],
    [ "writeByteData", "classLT__I2CBus.html#a764da5173c621582aa4f408f091fbfcb", null ],
    [ "writeWordData", "classLT__I2CBus.html#a22e9b78dd123a71b54c9e09d33606ee3", null ],
    [ "LT_I2CBus", "classLT__I2CBus.html#ad036e2aeea78c34e2ca088310ae777f8", null ],
    [ "LT_I2CBus", "classLT__I2CBus.html#a6865db290c4f4267aba4e27952a034cd", null ]
];