var CN0416__SerialPassthrough_8ino =
[
    [ "loop", "CN0416__SerialPassthrough_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "setup", "CN0416__SerialPassthrough_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ]
];